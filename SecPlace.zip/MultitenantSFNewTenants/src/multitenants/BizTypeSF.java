/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multitenants;

/**
 *
 * @author johannes.sianipar
 */
public enum BizTypeSF {    
    ConsumerGoods,Energy_and_Chemicals, Financial, Government, Healthcare, High_Tech, Higher_Education, Manufacturing, Media, Non_Profit, Retail, Hospitality, Travel, Staffing, Logistics, Security;    
    
    
}
