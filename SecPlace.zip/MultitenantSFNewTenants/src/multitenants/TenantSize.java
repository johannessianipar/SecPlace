/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multitenants;

/**
 *
 * @author johannes.sianipar
 */
public enum TenantSize {
    Small, Medium, Enterprise;
    
}
